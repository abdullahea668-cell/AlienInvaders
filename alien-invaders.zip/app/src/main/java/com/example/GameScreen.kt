package com.example

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import kotlin.math.sin
import kotlin.math.cos
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun GameScreen() {
    val context = LocalContext.current
    val soundGenerator = remember { RetroSoundGenerator() }
    val engine = remember { GameEngine(context, soundGenerator) }

    var autoFireEnabled by remember { mutableStateOf(false) }

    // Running the low-latency frame timer (approx. 60 FPS)
    LaunchedEffect(engine.gameState) {
        var lastTime = System.currentTimeMillis()
        while (true) {
            val now = System.currentTimeMillis()
            val elapsed = now - lastTime
            lastTime = now

            if (engine.gameState == GameState.PLAYING) {
                engine.update(elapsed)
                if (autoFireEnabled) {
                    engine.firePlayerLaser()
                }
            } else {
                engine.update(0) // update stars background animation even if paused
            }
            delay(16) // tick roughly at ~60fps
        }
    }

    // Edge-to-edge container box
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03000A))
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {

        // Canvas Game Board
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("game_board_canvas")
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        // Scale absolute drag to layout bounds
                        val normX = change.position.x / size.width
                        engine.targetPlayerX = normX * GAME_WIDTH
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { pressOffset ->
                        // Tap to move directly and shoot!
                        val normX = pressOffset.x / size.width
                        engine.targetPlayerX = normX * GAME_WIDTH
                        if (!autoFireEnabled) {
                            engine.firePlayerLaser()
                        }
                    }
                }
        ) {
            val scaleX = size.width / GAME_WIDTH
            val scaleY = size.height / GAME_HEIGHT

            // Use context-aware screen shake
            val shakeX = if (engine.screenShakeAmount > 0) (Random.nextFloat() * 2f - 1f) * engine.screenShakeAmount else 0f
            val shakeY = if (engine.screenShakeAmount > 0) (Random.nextFloat() * 2f - 1f) * engine.screenShakeAmount else 0f

            // 1. Draw Starfield
            engine.stars.forEach { star ->
                val drawX = star.x * scaleX + shakeX
                val drawY = star.y * scaleY + shakeY
                drawCircle(
                    color = star.color,
                    radius = star.size,
                    center = Offset(drawX, drawY)
                )
            }

            // 2. Draw Particles
            engine.particles.forEach { p ->
                val drawX = p.x * scaleX + shakeX
                val drawY = p.y * scaleY + shakeY
                drawCircle(
                    color = p.color.copy(alpha = p.alpha),
                    radius = p.radius * scaleX,
                    center = Offset(drawX, drawY)
                )
            }

            // 3. Draw Power-Ups on Board
            engine.powerUps.forEach { item ->
                val drawX = item.x * scaleX + shakeX
                val drawY = item.y * scaleY + shakeY
                val radius = item.radius * scaleX

                val color = when (item.type) {
                    PowerUpType.SHIELD -> Color.Cyan
                    PowerUpType.RAPID_FIRE -> Color.Red
                    PowerUpType.DOUBLE_LASER -> Color.Green
                    PowerUpType.MEGA_BLAST -> Color(0xFFD500F9)
                }

                // Pulsing outer aura ring
                val auraRadius = radius * (1.2f + 0.2f * sin(System.currentTimeMillis() / 150f).toFloat())
                drawCircle(
                    color = color.copy(alpha = 0.35f),
                    radius = auraRadius,
                    center = Offset(drawX, drawY)
                )

                // Solid capsule core
                drawCircle(
                    color = color,
                    radius = radius,
                    center = Offset(drawX, drawY)
                )

                // High contrast center core
                drawCircle(
                    color = Color.White,
                    radius = radius * 0.45f,
                    center = Offset(drawX, drawY)
                )
            }

            // 4. Draw Lasers
            engine.lasers.forEach { laser ->
                val lX = laser.x * scaleX + shakeX
                val lY = laser.y * scaleY + shakeY
                val lWidth = laser.width * scaleX
                val lHeight = laser.height * scaleY

                drawRoundRect(
                    color = laser.color,
                    topLeft = Offset(lX, lY),
                    size = Size(lWidth, lHeight),
                    cornerRadius = CornerRadius(10f, 10f),
                    style = Fill
                )
                // Draw inner glowing core
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(lX + lWidth * 0.25f, lY),
                    size = Size(lWidth * 0.5f, lHeight),
                    cornerRadius = CornerRadius(10f, 10f),
                    style = Fill
                )
            }

            // 5. Draw Aliens
            engine.aliens.forEach { alien ->
                val aX = alien.x * scaleX + shakeX
                val aY = alien.y * scaleY + shakeY
                val aW = alien.width * scaleX
                val aH = alien.height * scaleY
                val cX = aX + aW / 2f
                val cY = aY + aH / 2f

                when (alien.type) {
                    AlienType.SCOUT -> {
                        // Neon Green classic retro crab icon
                        val alienColor = Color(0xFF3CDD84)
                        
                        // Antenna lines
                        drawLine(alienColor, Offset(cX - 25f * scaleX, aY), Offset(cX - 10f * scaleX, aY + 15f * scaleY), strokeWidth = 5f)
                        drawLine(alienColor, Offset(cX + 25f * scaleX, aY), Offset(cX + 10f * scaleX, aY + 15f * scaleY), strokeWidth = 5f)

                        // Body shell
                        drawRoundRect(
                            alienColor,
                            topLeft = Offset(aX + 8f * scaleX, aY + 12f * scaleY),
                            size = Size(aW - 16f * scaleX, aH - 24f * scaleY),
                            cornerRadius = CornerRadius(8f, 8f)
                        )

                        // Claws/Wings bottom shapes
                        drawRect(alienColor, topLeft = Offset(aX + 8f * scaleX, aY + aH - 12f * scaleY), size = Size(15f * scaleX, 10f * scaleY))
                        drawRect(alienColor, topLeft = Offset(aX + 45f * scaleX, aY + aH - 8f * scaleY), size = Size(10f * scaleX, 8f * scaleY))
                        drawRect(alienColor, topLeft = Offset(aX + aW - 23f * scaleX, aY + aH - 12f * scaleY), size = Size(15f * scaleX, 10f * scaleY))

                        // Evil red eyes
                        drawCircle(Color.Black, radius = 6f, center = Offset(cX - 15f * scaleX, cY))
                        drawCircle(Color.Black, radius = 6f, center = Offset(cX + 15f * scaleX, cY))
                        drawCircle(Color.Red, radius = 3.5f, center = Offset(cX - 15f * scaleX, cY))
                        drawCircle(Color.Red, radius = 3.5f, center = Offset(cX + 15f * scaleX, cY))
                    }
                    AlienType.FIGHTER -> {
                        // Orange jet wedges
                        val alienColor = Color(0xFFFF9900)
                        val wingPath = Path().apply {
                            moveTo(cX, aY + aH) // bottom nose tip
                            lineTo(aX + aW, aY) // top-right wing tip
                            lineTo(cX, aY + aH * 0.35f) // back engine center
                            lineTo(aX, aY) // top-left wing tip
                            close()
                        }
                        drawPath(wingPath, color = alienColor, style = Fill)

                        // Laser turrets at ears
                        drawRect(Color.Gray, topLeft = Offset(aX + 5f * scaleX, aY), size = Size(8f * scaleX, 12f * scaleY))
                        drawRect(Color.Gray, topLeft = Offset(aX + aW - 13f * scaleX, aY), size = Size(8f * scaleX, 12f * scaleY))

                        // Yellow cockpit center visor
                        drawCircle(Color.Yellow, radius = 7f, center = Offset(cX, cY))
                    }
                    AlienType.ELITE -> {
                        // Glowing shielded cyber-saucer in electric blue
                        val alienColor = Color(0xFF00AAFF)

                        // Translucent rotating shield ripple effect
                        val pulse = 1f + 0.12f * sin(System.currentTimeMillis() / 100f).toFloat()
                        drawCircle(
                            color = Color(0xFF00FFFF).copy(alpha = 0.3f),
                            radius = (aW / 2f) * pulse,
                            center = Offset(cX, cY)
                        )
                        drawCircle(
                            color = Color(0xFF00BFFF),
                            radius = aW / 1.7f,
                            center = Offset(cX, cY),
                            style = Stroke(width = 3f)
                        )

                        // Saucer primary dome
                        drawCircle(alienColor, radius = aW / 2.7f, center = Offset(cX, cY))
                        drawRoundRect(
                            color = alienColor,
                            topLeft = Offset(aX, cY - 8f * scaleY),
                            size = Size(aW, 16f * scaleY),
                            cornerRadius = CornerRadius(5f, 5f)
                        )

                        // Red horizontal eye visor
                        drawRoundRect(
                            color = Color.Red,
                            topLeft = Offset(cX - 20f * scaleX, cY - 4f * scaleY),
                            size = Size(40f * scaleX, 8f * scaleY)
                        )
                    }
                    AlienType.BOMBER -> {
                        // Magenta heavy fortress structure
                        val alienColor = Color(0xFFFF0077)

                        drawRoundRect(
                            color = alienColor,
                            topLeft = Offset(aX, aY + 12f * scaleY),
                            size = Size(aW, aH - 24f * scaleY),
                            cornerRadius = CornerRadius(16f, 16f)
                        )

                        // Center biological bomb bulb
                        drawCircle(
                            color = Color(0xFFFFD100),
                            radius = 11f * scaleX,
                            center = Offset(cX, aY + aH - 12f * scaleY)
                        )

                        // Side cargo wings
                        drawRect(Color(0xFFBC0058), topLeft = Offset(aX - 8f * scaleX, aY + 15f * scaleY), size = Size(8f * scaleX, 22f * scaleY))
                        drawRect(Color(0xFFBC0058), topLeft = Offset(aX + aW, aY + 15f * scaleY), size = Size(8f * scaleX, 22f * scaleY))

                        // Double slot vision grids
                        drawRoundRect(Color.Black, topLeft = Offset(cX - 30f * scaleX, cY - 6f * scaleY), size = Size(20f * scaleX, 10f * scaleY), cornerRadius = CornerRadius(4f, 4f))
                        drawRoundRect(Color.Black, topLeft = Offset(cX + 10f * scaleX, cY - 6f * scaleY), size = Size(20f * scaleX, 10f * scaleY), cornerRadius = CornerRadius(4f, 4f))
                    }
                    AlienType.BOSS -> {
                        // Giant red skull-beast capital dreadnought!
                        val armorColor = Color(0xFFD60202)
                        val designPath = Path().apply {
                            moveTo(cX, aY + aH) // center spike pointing down
                            lineTo(aX + aW - 10f, aY + aH * 0.7f) // right mid wing
                            lineTo(aX + aW, aY + 40f) // right top wing tip
                            lineTo(cX + 80f, aY + 50f) 
                            lineTo(cX, aY) // top command dome
                            lineTo(cX - 80f, aY + 50f)
                            lineTo(aX, aY + 40f) // left top wing tip
                            lineTo(aX + 10f, aY + aH * 0.7f) // left mid wing
                            close()
                        }
                        drawPath(designPath, color = armorColor, style = Fill)

                        // Dynamic rear plasma exhausts (reactor glow yellow)
                        for (i in 0..4) {
                            val rX = aX + 60f * scaleX + i * 55f * scaleX
                            drawCircle(Color(0xFFFFEE00), radius = 14f, center = Offset(rX, aY + 14f * scaleY))
                            drawCircle(Color.Red, radius = 6f, center = Offset(rX, aY + 14f * scaleY))
                        }

                        // Evil yellow weapon visual ports
                        drawCircle(Color.Magenta, radius = 15f, center = Offset(cX - 65f * scaleX, cY + 10f * scaleY))
                        drawCircle(Color.Magenta, radius = 15f, center = Offset(cX + 65f * scaleX, cY + 10f * scaleY))

                        // Boss health indicator directly above boss head
                        val hBarW = aW * 0.8f
                        val hBarH = 14f
                        val hBarX = cX - hBarW / 2f
                        val hBarY = aY - 25f

                        drawRoundRect(
                            color = Color.Black.copy(alpha = 0.5f),
                            topLeft = Offset(hBarX, hBarY),
                            size = Size(hBarW, hBarH),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                        drawRoundRect(
                            color = Color.Red,
                            topLeft = Offset(hBarX, hBarY),
                            size = Size(hBarW * (alien.health / alien.maxHealth), hBarH),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                    }
                }
            }

            // 6. Draw Player Spaceship
            val p = engine.player
            val pX = p.x * scaleX + shakeX
            val pY = p.y * scaleY + shakeY
            val pW = p.width * scaleX
            val pH = p.height * scaleY

            // Engine Flicker flame trail
            if (Random.nextInt(3) != 0) {
                // Large jet thruster glow
                val flamePath = Path().apply {
                    moveTo(pX - 16f, pY + pH - 15f)
                    lineTo(pX, pY + pH + 30f) // long exhaust nose tip
                    lineTo(pX + 16f, pY + pH - 15f)
                    close()
                }
                drawPath(flamePath, color = Color(0xFFFF5200), style = Fill)

                // Hot inner yellow core
                val innerFlamePath = Path().apply {
                    moveTo(pX - 8f, pY + pH - 15f)
                    lineTo(pX, pY + pH + 15f)
                    lineTo(pX + 8f, pY + pH - 15f)
                    close()
                }
                drawPath(innerFlamePath, color = Color(0xFFFFE000), style = Fill)
            }

            // Player metal ship structure (Cyan/Teal Fighter)
            val pColor = Color(0xFF00FFD2)
            val shipPath = Path().apply {
                moveTo(pX, pY) // structural nose tip pointing up
                lineTo(pX + 25f * scaleX, pY + pH * 0.5f) // cockpit side right
                lineTo(pX + pW / 2f, pY + pH * 0.7f) // outer right wing
                lineTo(pX + pW / 2f - 10f, pY + pH) // rear wing step right
                lineTo(pX - pW / 2f + 10f, pY + pH) // rear wing step left
                lineTo(pX - pW / 2f, pY + pH * 0.7f) // outer left wing
                lineTo(pX - 25f * scaleX, pY + pH * 0.5f) // cockpit side left
                close()
            }
            drawPath(shipPath, color = pColor, style = Fill)

            // Dynamic blue visor
            drawCircle(Color(0xFF007AFA), radius = 10f, center = Offset(pX, pY + pH * 0.45f))

            // Dual wingtip side blasters
            drawRect(Color.Gray, topLeft = Offset(pX - pW / 2f + 5f, pY + pH * 0.4f), size = Size(6f * scaleX, 15f * scaleY))
            drawRect(Color.Gray, topLeft = Offset(pX + pW / 2f - 11f, pY + pH * 0.4f), size = Size(6f * scaleX, 15f * scaleY))

            // 7. Forcefield Shield active overlay bubble
            if (p.shieldActive) {
                val cycle = sin(System.currentTimeMillis() / 70f)
                val baseRad = pW * 0.95f
                val activeRad = baseRad + (cycle * 8f)
                
                drawCircle(
                    color = Color.Cyan.copy(alpha = 0.22f),
                    radius = activeRad,
                    center = Offset(pX, pY + pH / 2f)
                )
                drawCircle(
                    color = Color(0xFF00F0FF),
                    radius = activeRad,
                    center = Offset(pX, pY + pH / 2f),
                    style = Stroke(width = 4f)
                )
            }
        }

        // HUD Dashboard overlays (Score, Lives) at the top of game box
        HUDSection(
            score = engine.score,
            highScore = engine.highScore,
            health = engine.player.health,
            shield = engine.player.shield,
            level = engine.level,
            activePowerUp = engine.player.activePowerUp,
            powerUpTimeLeft = engine.player.powerUpTimerMs,
            onPauseClick = { engine.togglePause() }
        )

        // Game State Screens controller menu
        when (engine.gameState) {
            GameState.START_MENU -> {
                StartMenuScreen(
                    highScore = engine.highScore,
                    onStartClick = { engine.startGame() }
                )
            }
            GameState.PAUSED -> {
                PausedScreen(
                    onResume = { engine.togglePause() },
                    onRestart = { engine.restartGame() },
                    onMainMenu = { engine.returnToMenu() }
                )
            }
            GameState.LEVEL_COMPLETED -> {
                LevelClearedScreen(
                    wave = engine.level,
                    onNext = { engine.proceedToNextLevel() }
                )
            }
            GameState.GAME_OVER -> {
                GameOverScreen(
                    finalScore = engine.score,
                    highScore = engine.highScore,
                    level = engine.level,
                    onRestart = { engine.restartGame() },
                    onMainMenu = { engine.returnToMenu() }
                )
            }
            else -> {}
        }

        // Touch Control Panels overlay (Floating Touchpads!) at the bottom
        if (engine.gameState == GameState.PLAYING) {
            GameBottomControls(
                onLeftPress = {
                    engine.targetPlayerX = (engine.targetPlayerX - 80f).coerceAtLeast(60f)
                },
                onRightPress = {
                    engine.targetPlayerX = (engine.targetPlayerX + 80f).coerceAtMost(GAME_WIDTH - 60f)
                },
                onShootClick = {
                    if (!autoFireEnabled) {
                        engine.firePlayerLaser()
                    }
                },
                autoFire = autoFireEnabled,
                onAutoFireToggle = { autoFireEnabled = it }
            )
        }
    }
}

@Composable
fun HUDSection(
    score: Int,
    highScore: Int,
    health: Float,
    shield: Float,
    level: Int,
    activePowerUp: PowerUpType?,
    powerUpTimeLeft: Long,
    onPauseClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        // Player Score Card
        Column {
            Text(
                text = "SCORE",
                color = Color.Gray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = String.format("%06d", score),
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.testTag("score_counter")
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "WAVE: $level",
                color = if (level % 10 == 0) Color.Red else Color(0xFF00FF88),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        // Powerup Status Bar overlay inside cockpit HUD
        if (activePowerUp != null) {
            val color = when (activePowerUp) {
                PowerUpType.SHIELD -> Color.Cyan
                PowerUpType.RAPID_FIRE -> Color.Red
                PowerUpType.DOUBLE_LASER -> Color.Green
                PowerUpType.MEGA_BLAST -> Color(0xFFD500F9)
            }
            val label = when (activePowerUp) {
                PowerUpType.SHIELD -> "SHIELD ACTIVE"
                PowerUpType.RAPID_FIRE -> "RAPID FIRE"
                PowerUpType.DOUBLE_LASER -> "DOUBLE LASERS"
                PowerUpType.MEGA_BLAST -> "MEGA HYPERBLAST"
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = label,
                    color = color,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(3.dp))
                LinearProgressIndicator(
                    progress = { (powerUpTimeLeft / 10000f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .width(110.dp)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = color,
                    trackColor = color.copy(alpha = 0.25f),
                )
            }
        }

        // Health Indicators and Menu Trigger
        Column(horizontalAlignment = Alignment.End) {
            // Pause action icon
            IconButton(
                onClick = onPauseClick,
                modifier = Modifier
                    .size(36.dp)
                    .background(Color.White.copy(alpha = 0.15f), CircleShape)
                    .testTag("pause_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Pause",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Vital health status bar
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "HP ",
                    color = Color.Red,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                LinearProgressIndicator(
                    progress = { (health / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .width(90.dp)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Color.Red,
                    trackColor = Color.Red.copy(alpha = 0.22f)
                )
            }

            // Shield status indicator bar
            if (shield > 0) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SH ",
                        color = Color.Cyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    LinearProgressIndicator(
                        progress = { (shield / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .width(90.dp)
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = Color.Cyan,
                        trackColor = Color.Cyan.copy(alpha = 0.22f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "BEST: ${String.format("%06d", highScore)}",
                color = Color.LightGray,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun GameBottomControls(
    onLeftPress: () -> Unit,
    onRightPress: () -> Unit,
    onShootClick: () -> Unit,
    autoFire: Boolean,
    onAutoFireToggle: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 20.dp)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Column(
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            // Auto fire toggle element
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AUTO-FIRE",
                    color = if (autoFire) Color.Cyan else Color.Gray,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Switch(
                    checked = autoFire,
                    onCheckedChange = onAutoFireToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Cyan,
                        checkedTrackColor = Color(0xFF004D40),
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color.DarkGray
                    ),
                    modifier = Modifier.testTag("auto_fire_toggle")
                )
            }

            // Virtual Joystick directional pads
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Control Arrow
                Button(
                    onClick = onLeftPress,
                    modifier = Modifier
                        .size(68.dp)
                        .testTag("left_move_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White.copy(alpha = 0.12f),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("◀", fontSize = 26.sp)
                }

                // Laser Fire Command Trigger
                if (!autoFire) {
                    Button(
                        onClick = onShootClick,
                        modifier = Modifier
                            .height(68.dp)
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                            .testTag("shoot_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Red.copy(alpha = 0.8f),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(34.dp),
                        elevation = ButtonDefaults.buttonElevation(8.dp)
                    ) {
                        Text(
                            text = "FIRE LASER",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                // Right Control Arrow
                Button(
                    onClick = onRightPress,
                    modifier = Modifier
                        .size(68.dp)
                        .testTag("right_move_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White.copy(alpha = 0.12f),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("▶", fontSize = 26.sp)
                }
            }
        }
    }
}

@Composable
fun StartMenuScreen(
    highScore: Int,
    onStartClick: () -> Unit
) {
    // Elegant floating cosmic start pane
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Neon Pulsing Logo Title
            val infiniteTransition = rememberInfiniteTransition(label = "logo_pulse")
            val pulseScale by infiniteTransition.animateFloat(
                initialValue = 0.96f,
                targetValue = 1.04f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "scale"
            )

            Text(
                text = "ALIEN\nINVADERS",
                color = Color(0xFF00FF66),
                fontSize = (44f * pulseScale).sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center,
                lineHeight = 48.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Text(
                text = "RETRO ARCADE COLLIDER ENGINE",
                color = Color.Cyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // High Score Medal
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF130D22)),
                border = BorderStroke(1.dp, Color(0xFF5500FF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(bottom = 32.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🏆 HIGH SCORE: ",
                        color = Color.Yellow,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                    Text(
                        text = String.format("%06d", highScore),
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp
                    )
                }
            }

            // Power-ups legend card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, Color.DarkGray),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 36.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "COGNITIVE WEAPONS SYSTEMS:",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    PowerUpLegendRow(Color.Cyan, "SHIELD [S]", "Invulnerability shield block")
                    PowerUpLegendRow(Color.Red, "RAPID [R]", "Triples gun fire trigger speed")
                    PowerUpLegendRow(Color.Green, "DUAL [D]", "Twin laser bursts from wing tips")
                    PowerUpLegendRow(Color(0xFFC400FF), "MEGA [M]", "Hyper plasma blasts pierces hulls")
                }
            }

            // Start launch Button
            Button(
                onClick = onStartClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00FF66),
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .height(60.dp)
                    .fillMaxWidth(0.85f)
                    .testTag("start_game_button"),
                elevation = ButtonDefaults.buttonElevation(12.dp)
            ) {
                Text(
                    text = "LAUNCH DEFENSE",
                    fontSize = 17.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "DRAG / TAP TO MOVE AND FLIGHT STEER",
                color = Color.Gray,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun PowerUpLegendRow(color: Color, code: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .background(color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = code.first().toString(),
                fontSize = 8.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "$code - $desc",
            color = Color.LightGray,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun PausedScreen(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onMainMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F081D)),
            border = BorderStroke(2.dp, Color.Cyan),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .width(300.dp)
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "TRANSMISSION PAUSED",
                    color = Color.Cyan,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                )

                Button(
                    onClick = onResume,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("resume_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Cyan, contentColor = Color.Black)
                ) {
                    Text("RESUME BATTLE", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("restart_from_pause_button"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray)
                ) {
                    Text("ABORT & RESTART", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }

                TextButton(onClick = onMainMenu) {
                    Text("RETURN TO MAIN MENU", color = Color.Gray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun LevelClearedScreen(
    wave: Int,
    onNext: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Victorious title
            Text(
                text = "WAVE $wave CLEARED",
                color = Color(0xFF00FF66),
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Text(
                text = "Alien clusters obliterated. Preparing quantum hyperdrive...",
                color = Color.LightGray,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 40.dp).padding(bottom = 32.dp)
            )

            Button(
                onClick = onNext,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF66), contentColor = Color.Black),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .height(54.dp)
                    .width(180.dp)
                    .testTag("next_wave_button")
            ) {
                Text(
                    text = "NEXT ASSAULT",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
fun GameOverScreen(
    finalScore: Int,
    highScore: Int,
    level: Int,
    onRestart: () -> Unit,
    onMainMenu: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.95f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Alarm warning visual icon
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(Color(0xFF2C0202), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("☠", color = Color.Red, fontSize = 44.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "HULL BREACHED\nGAME OVER",
                color = Color.Red,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center,
                lineHeight = 32.sp,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // Mission Statistics Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF140202)),
                border = BorderStroke(1.dp, Color.Red),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 36.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "TACTICAL FLIGHT TELEMETRY:",
                        color = Color.Red,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    StatRow("Waves Repelled:", "$level")
                    StatRow("Final Ship Score:", String.format("%06d", finalScore))
                    StatRow("Operational Best:", String.format("%06d", highScore))
                }
            }

            Button(
                onClick = onRestart,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red, contentColor = Color.White),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier
                    .height(56.dp)
                    .fillMaxWidth(0.8f)
                    .testTag("restart_button"),
                elevation = ButtonDefaults.buttonElevation(8.dp)
            ) {
                Text(
                    text = "RE-DEPLOY FLIGHT",
                    fontSize = 16.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onMainMenu,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray),
                border = BorderStroke(1.dp, Color.DarkGray),
                shape = RoundedCornerShape(26.dp),
                modifier = Modifier
                    .height(48.dp)
                    .fillMaxWidth(0.8f)
            ) {
                Text(
                    text = "BASE ESCAPE TERMINAL",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun StatRow(label: String, valStr: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color.Gray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        Text(text = valStr, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
