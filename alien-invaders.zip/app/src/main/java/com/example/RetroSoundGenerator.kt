package com.example

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class RetroSoundGenerator {
    private val coroutineScope = CoroutineScope(Dispatchers.Default)

    fun playLaser() {
        coroutineScope.launch {
            generateAndPlaySweep(
                startFreq = 1100f,
                endFreq = 220f,
                durationMs = 120,
                waveType = WaveType.SQUARE,
                volumeMult = 0.25f
            )
        }
    }

    fun playDoubleLaser() {
        coroutineScope.launch {
            generateAndPlaySweep(
                startFreq = 1300f,
                endFreq = 300f,
                durationMs = 90,
                waveType = WaveType.SAWTOOTH,
                volumeMult = 0.25f
            )
        }
    }

    fun playMegaBlast() {
        coroutineScope.launch {
            generateAndPlaySweep(
                startFreq = 180f,
                endFreq = 950f,
                durationMs = 350,
                waveType = WaveType.SAWTOOTH,
                volumeMult = 0.45f
            )
        }
    }

    fun playExplosion() {
        coroutineScope.launch {
            generateAndPlayNoise(
                durationMs = 280,
                volumeMult = 0.5f
            )
        }
    }

    fun playAlienShoot() {
        coroutineScope.launch {
            generateAndPlaySweep(
                startFreq = 400f,
                endFreq = 80f,
                durationMs = 110,
                waveType = WaveType.SINE,
                volumeMult = 0.15f
            )
        }
    }

    fun playPowerUp() {
        coroutineScope.launch {
            generateAndPlayArpeggio(
                freqs = listOf(350f, 523.25f, 659.25f, 1046.50f),
                stepDurationMs = 70,
                volumeMult = 0.35f
            )
        }
    }

    fun playBossWarning() {
        coroutineScope.launch {
            for (i in 1..3) {
                generateAndPlaySweep(
                    startFreq = 80f,
                    endFreq = 160f,
                    durationMs = 220,
                    waveType = WaveType.SQUARE,
                    volumeMult = 0.6f
                )
                delay(300)
            }
        }
    }

    fun playPlayerHit() {
        coroutineScope.launch {
            generateAndPlaySweep(
                startFreq = 300f,
                endFreq = 60f,
                durationMs = 250,
                waveType = WaveType.SAWTOOTH,
                volumeMult = 0.4f
            )
        }
    }

    enum class WaveType { SINE, SQUARE, SAWTOOTH }

    private fun generateAndPlaySweep(
        startFreq: Float,
        endFreq: Float,
        durationMs: Int,
        waveType: WaveType = WaveType.SINE,
        volumeMult: Float = 0.5f
    ) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val samples = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val t = i.toFloat() / sampleRate
            val pct = i.toFloat() / numSamples
            val freq = startFreq + (endFreq - startFreq) * pct
            val angle = 2.0 * PI * freq * t

            val amplitude = (1.0f - pct) * 32767f * volumeMult
            val sampleVal = when (waveType) {
                WaveType.SINE -> sin(angle).toFloat()
                WaveType.SQUARE -> if (sin(angle) >= 0) 1.0f else -1.0f
                WaveType.SAWTOOTH -> {
                    val period = sampleRate / freq
                    val pos = if (period > 0) (i % period) / period else 0f
                    (pos * 2.0f - 1.0f)
                }
            }
            samples[i] = (sampleVal * amplitude).toInt().coerceIn(-32768, 32767).toShort()
        }
        playSamples(samples, sampleRate)
    }

    private fun generateAndPlayNoise(durationMs: Int, volumeMult: Float = 0.5f) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val samples = ShortArray(numSamples)
        val random = Random(42)

        for (i in 0 until numSamples) {
            val pct = i.toFloat() / numSamples
            val noise = random.nextFloat() * 2f - 1f
            // Low pass filtering/rumbling by damping fast sweeps
            val amplitude = (1.0f - pct) * 32767f * volumeMult
            samples[i] = (noise * amplitude).toInt().coerceIn(-32768, 32767).toShort()
        }
        playSamples(samples, sampleRate)
    }

    private fun generateAndPlayArpeggio(freqs: List<Float>, stepDurationMs: Int, volumeMult: Float = 0.4f) {
        val sampleRate = 22050
        val numSamplesPerStep = (sampleRate * (stepDurationMs / 1000.0)).toInt()
        val totalSamples = numSamplesPerStep * freqs.size
        val samples = ShortArray(totalSamples)

        for (s in freqs.indices) {
            val freq = freqs[s]
            val startIndex = s * numSamplesPerStep
            for (i in 0 until numSamplesPerStep) {
                val t = i.toFloat() / sampleRate
                val angle = 2.0 * PI * freq * t
                val pct = i.toFloat() / numSamplesPerStep
                val amplitude = (1.0f - pct * 0.3f) * 32767f * volumeMult
                samples[startIndex + i] = (sin(angle) * amplitude).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
        playSamples(samples, sampleRate)
    }

    private fun playSamples(samples: ShortArray, sampleRate: Int) {
        try {
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(samples, 0, samples.size)
            audioTrack.play()

            // Release AudioTrack resources once completed to prevent device descriptor issues
            coroutineScope.launch {
                delay((samples.size * 1000L / sampleRate) + 300L)
                try {
                    audioTrack.stop()
                    audioTrack.release()
                } catch (e: Exception) {
                    // Ignore transient clean errors
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
