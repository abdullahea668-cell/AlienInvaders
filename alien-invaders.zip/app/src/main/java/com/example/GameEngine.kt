package com.example

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// Virtual dimensions for robust adaptive scaling
const val GAME_WIDTH = 1000f
const val GAME_HEIGHT = 1800f

enum class GameState {
    START_MENU,
    PLAYING,
    PAUSED,
    LEVEL_COMPLETED,
    GAME_OVER
}

enum class AlienType {
    SCOUT,     // Classic green, lateral slides
    FIGHTER,   // Yellow, fires rapid single red lasers
    ELITE,     // Blue, shielded (requires 2 hits), drops extra-valuable powerups
    BOMBER,    // Magenta, heavy bomber, drops high damage biological bombs
    BOSS       // Massive red boss ship with a dynamic shield bar, fires fans of lasers!
}

enum class PowerUpType {
    SHIELD,
    RAPID_FIRE,
    DOUBLE_LASER,
    MEGA_BLAST
}

data class PlayerShip(
    var x: Float = GAME_WIDTH / 2f,
    val y: Float = 1600f,
    val width: Float = 120f,
    val height: Float = 90f,
    var health: Float = 100f,
    val maxHealth: Float = 100f,
    var shield: Float = 0f,
    val maxShield: Float = 100f,
    var activePowerUp: PowerUpType? = null,
    var powerUpTimerMs: Long = 0L,
    var shieldActive: Boolean = false
)

data class Alien(
    val id: Int,
    var x: Float,
    var y: Float,
    var width: Float,
    var height: Float,
    val type: AlienType,
    var health: Float,
    val maxHealth: Float,
    var speedX: Float,
    var speedY: Float,
    var stateTime: Float = 0f,
    var value: Int = 100
)

data class Laser(
    var x: Float,
    var y: Float,
    val width: Float = 10f,
    val height: Float = 35f,
    val speedY: Float,
    val isPlayerOwned: Boolean,
    val damage: Float = 25f,
    val color: Color = Color.Cyan,
    val isMega: Boolean = false
)

data class PowerUpItem(
    var x: Float,
    var y: Float,
    val radius: Float = 30f,
    val type: PowerUpType,
    val speedY: Float = 4.5f
)

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var radius: Float,
    val color: Color,
    var age: Float = 0f,
    val maxAge: Float = 40f,
    var alpha: Float = 1f
)

data class StarFieldStar(
    var x: Float,
    var y: Float,
    val speed: Float,
    val size: Float,
    val color: Color
)

class GameEngine(
    private val context: Context,
    private val soundGenerator: RetroSoundGenerator
) {
    private val prefs = context.getSharedPreferences("alien_invaders_prefs", Context.MODE_PRIVATE)

    // Observable states bound dynamically to the composables
    var gameState by mutableStateOf(GameState.START_MENU)
        private set

    var score by mutableStateOf(0)
        private set

    var highScore by mutableStateOf(prefs.getInt("high_score", 0))
        private set

    var level by mutableStateOf(1)
        private set

    var player by mutableStateOf(PlayerShip())
        private set

    // Thread-safe lists for asynchronous updates or modifications
    val aliens = CopyOnWriteArrayList<Alien>()
    val lasers = CopyOnWriteArrayList<Laser>()
    val powerUps = CopyOnWriteArrayList<PowerUpItem>()
    val particles = CopyOnWriteArrayList<Particle>()
    val stars = ArrayList<StarFieldStar>()

    // Wave progression metrics
    private var alienDirection = 1f // 1 = right, -1 = left
    private var alienBaseSpeed = 2f
    private var alienShootAccumulator = 0f
    private var nextAlienId = 0

    // Touch controls helper state
    var targetPlayerX by mutableStateOf(GAME_WIDTH / 2f)

    // Screen Shake Effect for feedback
    var screenShakeAmount by mutableStateOf(0f)
        private set

    init {
        generateStarField()
    }

    private fun generateStarField() {
        stars.clear()
        val random = Random(1337)
        for (i in 0 until 120) {
            val layer = random.nextInt(3)
            val speed = when (layer) {
                0 -> 1.5f  // Distant stars
                1 -> 4.0f  // Mid stars
                else -> 7.5f // Foreground space debris
            }
            val size = when (layer) {
                0 -> 1.5f
                1 -> 3.2f
                else -> 5.0f
            }
            val color = when (layer) {
                0 -> Color(0xFF59639F)
                1 -> Color(0xFFC7CFFA)
                else -> Color(0xFFFFEFA3)
            }
            stars.add(
                StarFieldStar(
                    x = random.nextFloat() * GAME_WIDTH,
                    y = random.nextFloat() * GAME_HEIGHT,
                    speed = speed,
                    size = size,
                    color = color
                )
            )
        }
    }

    fun startGame() {
        score = 0
        level = 1
        alienBaseSpeed = 2.5f
        player = PlayerShip()
        targetPlayerX = GAME_WIDTH / 2f
        aliens.clear()
        lasers.clear()
        powerUps.clear()
        particles.clear()
        
        spawnAlienWave()
        gameState = GameState.PLAYING
    }

    fun togglePause() {
        if (gameState == GameState.PLAYING) {
            gameState = GameState.PAUSED
        } else if (gameState == GameState.PAUSED) {
            gameState = GameState.PLAYING
        }
    }

    fun restartGame() {
        startGame()
    }

    fun returnToMenu() {
        gameState = GameState.START_MENU
    }

    private fun spawnAlienWave() {
        aliens.clear()
        lasers.clear()
        powerUps.clear()
        nextAlienId = 0
        alienDirection = 1f

        if (level % 10 == 0) {
            // Boss Alien Alert Level!
            soundGenerator.playBossWarning()
            val hp = 400f + (level * 50f)
            aliens.add(
                Alien(
                    id = nextAlienId++,
                    x = GAME_WIDTH / 2f - 175f,
                    y = 200f,
                    width = 350f,
                    height = 200f,
                    type = AlienType.BOSS,
                    health = hp,
                    maxHealth = hp,
                    speedX = 3.5f + (level * 0.15f),
                    speedY = 0f,
                    value = level * 1000
                )
            )
        } else {
            // Standard Grid Invasion Swarm
            // Columns: 7, Rows: 4
            val cols = 7
            val rows = 4
            val cellWidth = 100f
            val cellHeight = 75f
            val startOffsetX = (GAME_WIDTH - (cols * cellWidth + (cols - 1) * 30f)) / 2f
            val startOffsetY = 250f

            for (row in 0 until rows) {
                for (col in 0 until cols) {
                    val alienType = when (row) {
                        0 -> if (level >= 5) AlienType.BOMBER else AlienType.ELITE
                        1 -> if (level >= 3) AlienType.ELITE else AlienType.FIGHTER
                        2 -> AlienType.FIGHTER
                        else -> AlienType.SCOUT
                    }

                    // Setup alien attributes
                    val maxHp = when (alienType) {
                        AlienType.BOMBER -> 80f + (level * 5f)
                        AlienType.ELITE -> 60f + (level * 5f)
                        AlienType.FIGHTER -> 35f + (level * 3f)
                        else -> 20f + (level * 2f)
                    }

                    val points = when (alienType) {
                        AlienType.BOMBER -> 450
                        AlienType.ELITE -> 300
                        AlienType.FIGHTER -> 200
                        else -> 100
                    }

                    val alienX = startOffsetX + col * (cellWidth + 30f)
                    val alienY = startOffsetY + row * (cellHeight + 35f)

                    aliens.add(
                        Alien(
                            id = nextAlienId++,
                            x = alienX,
                            y = alienY,
                            width = cellWidth,
                            height = cellHeight,
                            type = alienType,
                            health = maxHp,
                            maxHealth = maxHp,
                            speedX = alienBaseSpeed + (level * 0.1f),
                            speedY = 12f, // Descent step
                            value = points
                        )
                    )
                }
            }
        }
    }

    fun firePlayerLaser() {
        if (gameState != GameState.PLAYING) return

        val now = System.currentTimeMillis()
        val cooldown = if (player.activePowerUp == PowerUpType.RAPID_FIRE) 130L else 380L

        // Double laser wing locations
        val lWing = player.x - player.width / 2f + 10f
        val rWing = player.x + player.width / 2f - 20f

        when (player.activePowerUp) {
            PowerUpType.DOUBLE_LASER -> {
                soundGenerator.playDoubleLaser()
                lasers.add(Laser(x = lWing, y = player.y - 10f, speedY = -23f, isPlayerOwned = true, damage = 25f, color = Color.Green))
                lasers.add(Laser(x = rWing, y = player.y - 10f, speedY = -23f, isPlayerOwned = true, damage = 25f, color = Color.Green))
            }
            PowerUpType.MEGA_BLAST -> {
                soundGenerator.playMegaBlast()
                lasers.add(Laser(
                    x = player.x - 20f,
                    y = player.y - 25f,
                    width = 40f,
                    height = 55f,
                    speedY = -16f,
                    isPlayerOwned = true,
                    damage = 75f,
                    color = Color(0xFFA000FF), // Neon Purple
                    isMega = true
                ))
            }
            else -> {
                // Standard default single central laser
                soundGenerator.playLaser()
                lasers.add(Laser(x = player.x - 5f, y = player.y - 15f, speedY = -25f, isPlayerOwned = true, damage = 30f, color = Color.Cyan))
            }
        }
    }

    fun update(deltaTimeMs: Long) {
        if (gameState != GameState.PLAYING) {
            // Update stars anyway to provide a live dynamic background
            updateStars()
            return
        }

        // Dampen screen shake
        if (screenShakeAmount > 0) {
            screenShakeAmount = (screenShakeAmount - 0.5f).coerceAtLeast(0f)
        }

        // Core physics ticks
        updateStars()
        updatePlayerState(deltaTimeMs)
        updateLasers()
        updateAliens(deltaTimeMs)
        updatePowerUps()
        updateParticles()
        checkCollisions()
    }

    private fun updateStars() {
        stars.forEach { star ->
            star.y += star.speed
            if (star.y > GAME_HEIGHT) {
                star.y = 0f
                star.x = Random.nextFloat() * GAME_WIDTH
            }
        }
    }

    private fun updatePlayerState(deltaTimeMs: Long) {
        // Smoothly slide players towards target dragging point
        val diff = targetPlayerX - player.x
        // High inertia speed mapping
        player.x += diff * 0.35f
        player.x = player.x.coerceIn(player.width / 2f + 10f, GAME_WIDTH - player.width / 2f - 10f)

        // Count down active powerup times
        if (player.activePowerUp != null) {
            val rem = player.powerUpTimerMs - deltaTimeMs
            if (rem <= 0) {
                // Decay power-up
                if (player.activePowerUp == PowerUpType.SHIELD) {
                    player.shieldActive = false
                    player.shield = 0f
                }
                player.activePowerUp = null
                player.powerUpTimerMs = 0L
            } else {
                player.powerUpTimerMs = rem
                if (player.activePowerUp == PowerUpType.SHIELD) {
                    player.shield = (rem.toFloat() / 10000f) * player.maxShield
                }
            }
        }
    }

    private fun updateLasers() {
        lasers.forEach { laser ->
            laser.y += laser.speedY
        }
        // Garbage collection for off-screen lasers
        lasers.removeIf { it.y < -100f || it.y > GAME_HEIGHT + 100f }
    }

    private fun updateAliens(deltaTimeMs: Long) {
        if (aliens.isEmpty()) return

        alienShootAccumulator += (deltaTimeMs / 16.67f)

        // Determine if grid swarm needs descent and reversal
        var stepDownRequired = false
        val isBossInWave = aliens.any { it.type == AlienType.BOSS }

        if (!isBossInWave) {
            for (alien in aliens) {
                alien.x += alien.speedX * alienDirection
                // Border collision trigger
                if (alienDirection > 0f && alien.x + alien.width >= GAME_WIDTH - 15f) {
                    stepDownRequired = true
                } else if (alienDirection < 0f && alien.x <= 15f) {
                    stepDownRequired = true
                }
            }

            if (stepDownRequired) {
                alienDirection *= -1f // Reverse flow
                for (alien in aliens) {
                    alien.y += alien.speedY // Descend aliens closer to bottom!
                    
                    // Invasion breach check (Invasion reaches player!)
                    if (alien.y + alien.height >= player.y - 10f) {
                        triggerGameOver()
                        return
                    }
                }
            }
        } else {
            // Boss movement pathing behavior
            val boss = aliens.firstOrNull { it.type == AlienType.BOSS }
            if (boss != null) {
                boss.stateTime += (deltaTimeMs / 1000f)
                boss.x += boss.speedX * alienDirection
                
                // Keep boss in range, moving smoothly
                if (alienDirection > 0f && boss.x + boss.width >= GAME_WIDTH - 25f) {
                    alienDirection = -1f
                } else if (alienDirection < 0f && boss.x <= 25f) {
                    alienDirection = 1f
                }

                // Periodic Boss Shooting Attacks
                if (alienShootAccumulator >= 45f) {
                    alienShootAccumulator = 0f
                    soundGenerator.playAlienShoot()
                    
                    // Fires 3 directions simultaneously inside a fan shape
                    val centerX = boss.x + boss.width / 2f
                    val bottomY = boss.y + boss.height - 15f
                    
                    lasers.add(Laser(x = centerX, y = bottomY, speedY = 12f, isPlayerOwned = false, damage = 20f, color = Color.Red))
                    lasers.add(Laser(x = centerX - 80f, y = bottomY, speedY = 11f, isPlayerOwned = false, damage = 15f, color = Color(0xFFFF5500)))
                    lasers.add(Laser(x = centerX + 80f, y = bottomY, speedY = 11f, isPlayerOwned = false, damage = 15f, color = Color(0xFFFF5500)))
                }
                return
            }
        }

        // Regular alien firing check (increases in rate with levels)
        val shootProbability = 0.015f + (level * 0.002f)
        if (alienShootAccumulator >= 35f) {
            alienShootAccumulator = 0f
            
            // Randomly select one tactical alien from row bottoms to shoot feedback lasers
            val firingCandidates = aliens.filter { it.type != AlienType.BOSS }
            if (firingCandidates.isNotEmpty()) {
                val shooter = firingCandidates[Random.nextInt(firingCandidates.size)]
                
                if (Random.nextFloat() < shootProbability.coerceAtMost(0.18f)) {
                    soundGenerator.playAlienShoot()
                    val projectileY = shooter.y + shooter.height
                    val projectileX = shooter.x + shooter.width / 2f
                    
                    when (shooter.type) {
                        AlienType.BOMBER -> {
                            // Heavy biological plasma drop
                            lasers.add(Laser(
                                x = projectileX - 10f,
                                y = projectileY,
                                width = 24f,
                                height = 45f,
                                speedY = 9.5f,
                                isPlayerOwned = false,
                                damage = 40f,
                                color = Color(0xFFFF00FF)
                            ))
                        }
                        AlienType.FIGHTER -> {
                            // Rapid dual blaster
                            lasers.add(Laser(x = projectileX - 15f, y = projectileY, speedY = 16f, isPlayerOwned = false, damage = 15f, color = Color.Red))
                            lasers.add(Laser(x = projectileX + 5f, y = projectileY, speedY = 16f, isPlayerOwned = false, damage = 15f, color = Color.Red))
                        }
                        else -> {
                            // Standard single red shot
                            lasers.add(Laser(x = projectileX - 4f, y = projectileY, speedY = 13f, isPlayerOwned = false, damage = 10f, color = Color.Red))
                        }
                    }
                }
            }
        }
    }

    private fun updatePowerUps() {
        powerUps.forEach { item ->
            item.y += item.speedY
        }
        // Remove offscreen power-ups
        powerUps.removeIf { it.y > GAME_HEIGHT + 50f }
    }

    private fun updateParticles() {
        particles.forEach { p ->
            p.x += p.vx
            p.y += p.vy
            p.age += 1f
            p.alpha = (1f - p.age / p.maxAge).coerceIn(0f, 1f)
        }
        particles.removeIf { it.age >= it.maxAge }
    }

    private fun checkCollisions() {
        // 1. Lasers vs Aliens
        for (laser in lasers) {
            if (!laser.isPlayerOwned) continue

            for (alien in aliens) {
                // Box collider check
                if (laser.x + laser.width >= alien.x &&
                    laser.x <= alien.x + alien.width &&
                    laser.y + laser.height >= alien.y &&
                    laser.y <= alien.y + alien.height
                ) {
                    // Collision occurred!
                    alien.health -= laser.damage
                    
                    // Visual screen shake and particles
                    screenShakeAmount = if (laser.isMega) 8f else 3f
                    spawnExplosionParticles(laser.x + laser.width / 2f, laser.y, alien.type)

                    // Mega blasts pierce standard targets (keeping their speed but decreasing charge slightly)
                    if (!laser.isMega) {
                        lasers.remove(laser)
                    }

                    if (alien.health <= 0) {
                        // Alien killed!
                        aliens.remove(alien)
                        score += alien.value
                        soundGenerator.playExplosion()
                        spawnExplosionParticles(alien.x + alien.width / 2f, alien.y + alien.height / 2f, alien.type, isKilled = true)

                        // Update device local high score immediately to avoid data loss
                        if (score > highScore) {
                            highScore = score
                            prefs.edit().putInt("high_score", highScore).apply()
                        }

                        // Roll chance for random capsule drop
                        val lootChance = 0.14f
                        if (Random.nextFloat() <= lootChance && alien.type != AlienType.BOSS) {
                            // Choose random power-up drop
                            val types = PowerUpType.values()
                            val choice = types[Random.nextInt(types.size)]
                            powerUps.add(
                                PowerUpItem(
                                    x = alien.x + alien.width / 2f,
                                    y = alien.y + alien.height / 2f,
                                    type = choice
                                )
                            )
                        }

                        // Level Completion check
                        if (aliens.isEmpty()) {
                            triggerLevelCompleted()
                        }
                    }
                    break
                }
            }
        }

        // 2. Lasers vs Player
        for (laser in lasers) {
            if (laser.isPlayerOwned) continue

            // Bounding collision box for spaceship
            val playerLeft = player.x - player.width / 2f
            val playerRight = player.x + player.width / 2f

            if (laser.x + laser.width >= playerLeft &&
                laser.x <= playerRight &&
                laser.y + laser.height >= player.y &&
                laser.y <= player.y + player.height
            ) {
                lasers.remove(laser)

                if (player.shieldActive) {
                    // Absorb damage cleanly inside shield
                    screenShakeAmount = 4f
                    spawnShieldDeflectParticles(laser.x, player.y)
                } else {
                    // Direct shieldless hit
                    player.health = (player.health - laser.damage).coerceAtLeast(0f)
                    screenShakeAmount = 14f
                    soundGenerator.playPlayerHit()
                    spawnDamageParticles(player.x, player.y)
                    
                    if (player.health <= 0f) {
                        triggerGameOver()
                    }
                }
            }
        }

        // 3. PowerUps vs Player
        val playerLeft = player.x - player.width / 2f
        val playerRight = player.x + player.width / 2f

        for (item in powerUps) {
            if (item.x + item.radius >= playerLeft &&
                item.x - item.radius <= playerRight &&
                item.y + item.radius >= player.y &&
                item.y - item.radius <= player.y + player.height
            ) {
                // Collect upgrading capsule!
                powerUps.remove(item)
                soundGenerator.playPowerUp()
                
                player.activePowerUp = item.type
                player.powerUpTimerMs = 10000L // 10 full seconds duration for all boosts
                
                if (item.type == PowerUpType.SHIELD) {
                    player.shieldActive = true
                    player.shield = player.maxShield
                }
                
                score += 50 // bonus points for powerups!
                spawnCollectParticles(player.x, player.y, item.type)
            }
        }
    }

    private fun spawnExplosionParticles(x: Float, y: Float, type: AlienType, isKilled: Boolean = false) {
        val color = when (type) {
            AlienType.BOMBER -> Color(0xFFFF00FF)
            AlienType.ELITE -> Color(0xFF00BFFF)
            AlienType.FIGHTER -> Color(0xFFFFCC00)
            AlienType.SCOUT -> Color(0xFF3CDD84)
            AlienType.BOSS -> Color(0xFFFF1111)
        }
        val count = if (isKilled) (if (type == AlienType.BOSS) 70 else 25) else 6
        val rand = Random(42)

        for (i in 0 until count) {
            val speed = if (isKilled) rand.nextFloat() * 11f + 3f else rand.nextFloat() * 6f + 2f
            val angle = rand.nextDouble() * 2.0 * Math.PI
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = (speed * cos(angle)).toFloat(),
                    vy = (speed * sin(angle)).toFloat(),
                    radius = rand.nextFloat() * 4.5f + 2.5f,
                    color = color,
                    maxAge = rand.nextFloat() * 30f + 20f
                )
            )
        }
    }

    private fun spawnShieldDeflectParticles(x: Float, y: Float) {
        val rand = Random
        for (i in 0 until 12) {
            val angle = rand.nextDouble() * Math.PI + Math.PI // Sprays upward
            val speed = rand.nextFloat() * 7f + 2f
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = (speed * cos(angle)).toFloat(),
                    vy = (speed * sin(angle)).toFloat(),
                    radius = rand.nextFloat() * 4f + 2f,
                    color = Color.Cyan,
                    maxAge = rand.nextFloat() * 20f + 10f
                )
            )
        }
    }

    private fun spawnCollectParticles(x: Float, y: Float, type: PowerUpType) {
        val color = when (type) {
            PowerUpType.SHIELD -> Color.Cyan
            PowerUpType.RAPID_FIRE -> Color.Red
            PowerUpType.DOUBLE_LASER -> Color.Green
            PowerUpType.MEGA_BLAST -> Color(0xFFC400FF)
        }
        val rand = Random
        for (i in 0 until 20) {
            val angle = rand.nextDouble() * 2.0 * Math.PI
            val speed = rand.nextFloat() * 5f + 1.5f
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = (speed * cos(angle)).toFloat(),
                    vy = (speed * sin(angle)).toFloat(),
                    radius = rand.nextFloat() * 3.5f + 1.5f,
                    color = color,
                    maxAge = rand.nextFloat() * 30f + 15f
                )
            )
        }
    }

    private fun spawnDamageParticles(x: Float, y: Float) {
        val rand = Random
        for (i in 0 until 18) {
            val angle = rand.nextDouble() * 2.0 * Math.PI
            val speed = rand.nextFloat() * 9f + 2f
            particles.add(
                Particle(
                    x = x,
                    y = y,
                    vx = (speed * cos(angle)).toFloat(),
                    vy = (speed * sin(angle)).toFloat(),
                    radius = rand.nextFloat() * 5f + 2f,
                    color = Color(0xFFFF4500), // Fire Red
                    maxAge = rand.nextFloat() * 35f + 15f
                )
            )
        }
    }

    private fun triggerLevelCompleted() {
        gameState = GameState.LEVEL_COMPLETED
    }

    fun proceedToNextLevel() {
        level++
        alienBaseSpeed += 0.35f // Increase overall visual difficulty speed
        spawnAlienWave()
        gameState = GameState.PLAYING
    }

    private fun triggerGameOver() {
        gameState = GameState.GAME_OVER
        soundGenerator.playExplosion()
        spawnDamageParticles(player.x, player.y)
    }
}
